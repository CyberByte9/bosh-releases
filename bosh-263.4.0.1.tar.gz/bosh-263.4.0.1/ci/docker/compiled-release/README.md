This directory contains the Docker image which will be used for compiling releases. We publish this to
Docker Hub at [`bosh/compiled-release`](https://hub.docker.com/r/bosh/compiled-release/)

## Testing bosh-init functionality

Check if bosh-init installed
    
    container$ bosh-init -v
