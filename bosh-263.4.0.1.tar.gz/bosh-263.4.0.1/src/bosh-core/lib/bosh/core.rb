module Bosh
  module Core
  end
end
