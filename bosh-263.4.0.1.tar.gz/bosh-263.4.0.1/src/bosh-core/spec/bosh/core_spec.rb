require 'spec_helper'
require 'bosh/core'

describe Bosh::Core do
  it { should be_a(Module) }
end
