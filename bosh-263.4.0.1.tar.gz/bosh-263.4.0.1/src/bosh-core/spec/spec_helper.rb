require File.expand_path('../../../spec/shared/spec_helper', __FILE__)
